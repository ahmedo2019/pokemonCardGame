import java.util.Scanner;
import java.util.*;
import java.lang.Math;
import java.util.Arrays;

public class Game{
	
public static void main(String[] args) {
	// will execute the game by calling the class Multiplay from the file Multiplay
	// which will run the game inputs and sequences 
	Multiplayer.Multiplay();

	}
}