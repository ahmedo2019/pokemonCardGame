package gui;

import static org.junit.Assert.*;

import org.junit.Test;

public class baseSceneTest {

	@Test
	public final void testBaseScene() {
		assertTrue(true);
	}

	@Test
	public final void testGetScene() {
		assertTrue(true);
	}

	@Test
	public final void testSetScene() {
		assertTrue(true);
	}

	@Test
	public final void testGetMenu() {
		assertTrue(true);
	}

	@Test
	public final void testSetMenu() {
		assertTrue(true);
	}

	@Test
	public final void testSetup() {
		assertTrue(true);
	}

	@Test
	public final void testDisplay() {
		assertTrue(true);
	}

	@Test
	public final void testObject() {
		assertTrue(true);
	}

	@Test
	public final void testGetClass() {
		assertTrue(true);
	}

	@Test
	public final void testHashCode() {
		assertTrue(true);
	}

	@Test
	public final void testEquals() {
		assertTrue(true);
	}

	@Test
	public final void testClone() {
		assertTrue(true);
	}

	@Test
	public final void testToString() {
		assertTrue(true);
	}

	@Test
	public final void testNotify() {
		assertTrue(true);
	}

	@Test
	public final void testNotifyAll() {
		assertTrue(true);
	}

	@Test
	public final void testWaitLong() {
		assertTrue(true);
	}

	@Test
	public final void testWaitLongInt() {
		assertTrue(true);
	}

	@Test
	public final void testWait() {
		assertTrue(true);
	}

	@Test
	public final void testFinalize() {
		assertTrue(true);
	}

}
